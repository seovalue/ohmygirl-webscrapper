# ohmygirl-webscrapper
매일 업데이트되는 오마이걸의 새로운 영상 링크를 받아오는 web scrapper

[확인하기](https://seovalue.github.io/ohmygirl-webscrapper/index.html)

<h3>실행방법</h3>
zip파일을 다운로드 받은 뒤, main.exe 파일을 실행시킵니다.

css 해줄사람......

* 수정해야될 것 -> 겹치는 내용 삭제 또는 dictionary로 해서 dataframe 만들기*
